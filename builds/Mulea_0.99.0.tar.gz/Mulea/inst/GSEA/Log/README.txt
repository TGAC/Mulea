Directory use to save reult.txt file.
It is file prodused by GSEA program.
