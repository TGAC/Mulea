
.onAttach <- function(libname, pkgname) {
    packageStartupMessage("Welcome to Mulea package!")
}
