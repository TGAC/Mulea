# Packages development.
install.packages(c("devtools", "roxygen2", "testthat", "knitr", "rmarkdown"))
devtools::install_github("hadley/devtools")
install.packages("rstudioapi")
library(devtools)
devtools::has_devel()
sessionInfo()

# Build with vignetts.
devtools::use_vignette(name = "Mulea")
devtools::build_vignettes()
devtools::build()
devtools::build(binary = TRUE, args = c('--preclean'))
devtools::install()
vignette("Mulea")


# Mulea uses.
install.packages(c("DBI", "RSQLite"))

# R things.
R.Version()

# BioConductor important steps.
# IMPORTANT note : if some errors restart session or restard IDE!
source("https://bioconductor.org/biocLite.R")
library(BiocInstaller)
BiocInstaller::useDevel()
BiocInstaller::biocValid()
BiocInstaller::biocLite()
# R CMD BiocCheck
biocLite("BiocCheck")
library(BiocCheck)
#Do BiocCheck on development version of package, not installed. :P
BiocCheck("/home/koralgooll/doktorat/Rpackages/mulea/Mulea")
#Not this directory:
find.package("Mulea")
# KNOWN BUG
#Failed to copy the script/BiocCheck script to /usr/lib/R/bin. If you want to be able to
#run 'R CMD BiocCheck' you'll need to copy it yourself to a directory on your PATH, making
#sure it is executable. See the BiocCheck vignette for more information.
# SOLUTION
find.package("BiocCheck")
#Do what is in instruction. Copy that file please. :)


# WORK HELPERS
# Clean screen.
cat("\014")
