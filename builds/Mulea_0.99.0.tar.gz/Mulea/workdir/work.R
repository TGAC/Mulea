# Test of methods usage:

# Run BioConductor complience test.
